import SwiftUI

enum Images: CaseIterable {
    case wizardLibrary
    case spaceWhale
    case astronautOopsy
    case elfFairyLand
    case whichDoor
    case pirateShip
    case foxTeaParty
    case treasure
}
